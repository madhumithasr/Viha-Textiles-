// src/components/ProductionRegister.tsx
import type { ChangeEvent } from "react";
import { useState, useEffect } from "react";
import { Search, Plus, Eye, Trash2, QrCode } from "lucide-react";
import { Client, Design } from "../types";

/** --- Domain types used in this component --- */
type OrderStatus = "Pending" | "In Production" | "Completed" | "Cancelled";

interface Order {
  id: string;
  order_no: string;
  order_date: string; // YYYY-MM-DD
  qty_ordered: number;
  rate_per_piece: number;
  status: OrderStatus;
  client_id?: string;
  design_id?: string;
  batch_lot_no?: string;
  expected_delivery_date?: string;
  grey_material_issued?: string;
  remarks?: string;
  clients?: Client | null;
  designs?: Design | null;
}

export function ProductionRegister() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [designs, setDesigns] = useState<Design[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("");

  useEffect(() => {
    fetchData();
  }, []);

  /** ----------------------------
   *  MOCK FETCH (replace with real API)
   * ----------------------------*/
  async function fetchData() {
    try {
      // NOTE: adjust fields to match your actual Client / Design definitions in ../types
      const mockClients: Client[] = [
        {
          id: "1",
          sr_no: 1,
          client_name: "ABC Textiles",
          mobile: "9999999999",
          alternate_mobile: "",
          city_area: "Mumbai",
          client_type: "Retail",
          gst_no: "",
          opening_balance: 0,
          notes: "",
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
        {
          id: "2",
          sr_no: 2,
          client_name: "Fashion House",
          mobile: "8888888888",
          alternate_mobile: "",
          city_area: "Delhi",
          client_type: "Wholesale",
          gst_no: "",
          opening_balance: 0,
          notes: "",
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
      ];

      const mockDesigns: Design[] = [
        {
          id: "1",
          design_code: "D-1001",
          design_name: "Floral Print",
          default_rate: 12,
          default_mrp: 0,
          opening_stock: 0,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
        {
          id: "2",
          design_code: "D-2002",
          design_name: "Geometric Pattern",
          default_rate: 15,
          default_mrp: 0,
          opening_stock: 0,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
      ];

      const mockOrders: Order[] = [
        {
          id: "101",
          order_no: "PO-101",
          order_date: "2025-01-15",
          qty_ordered: 1000,
          rate_per_piece: 12,
          status: "Pending",
          client_id: "1",
          design_id: "1",
          batch_lot_no: "",
          expected_delivery_date: "",
          grey_material_issued: "",
          remarks: "",
          clients: mockClients[0],
          designs: mockDesigns[0],
        },
      ];

      setClients(mockClients);
      setDesigns(mockDesigns);
      setOrders(mockOrders);
    } catch (err) {
      // keep safe logging

      console.error("Error loading data:", err);
    } finally {
      setLoading(false);
    }
  }

  /** ----------------------------
   *  ADD NEW ORDER (LOCAL ONLY)
   * ----------------------------*/
  async function addNewOrder() {
    const newOrder: Order = {
      id: String(Date.now()),
      order_no: `PO-${Date.now()}`,
      order_date: new Date().toISOString().split("T")[0],
      qty_ordered: 0,
      rate_per_piece: 0,
      status: "Pending",
      client_id: "",
      design_id: "",
      batch_lot_no: "",
      expected_delivery_date: "",
      grey_material_issued: "",
      remarks: "",
      clients: null,
      designs: null,
    };

    setOrders((prev) => [newOrder, ...prev]);
  }

  /** ----------------------------
   *  Strongly-typed UPDATE ORDER
   *  value is typed to match the Order field type
   *
   *  SMALL CHANGE: when design_id is changed we now also auto-fill
   *  rate_per_piece from the design's default_rate (if available).
   * ----------------------------*/
  async function updateOrder<K extends keyof Order>(
    id: string,
    field: K,
    value: Order[K]
  ) {
    setOrders((prev) =>
      prev.map((o) =>
        o.id === id
          ? ({
              ...o,
              [field]: value,
              // When client_id changes, update joined object.
              ...(field === "client_id"
                ? {
                    clients:
                      clients.find(
                        (c) => c.id === (value as unknown as string)
                      ) || null,
                  }
                : {}),
              // When design_id changes, update joined object AND
              // auto-fill rate_per_piece from design.default_rate if found.
              ...(field === "design_id"
                ? (() => {
                    const selectedDesign = designs.find(
                      (d) => d.id === (value as unknown as string)
                    );
                    return {
                      designs: selectedDesign || null,
                      rate_per_piece:
                        selectedDesign?.default_rate ?? o.rate_per_piece,
                    };
                  })()
                : {}),
            } as Order)
          : o
      )
    );
  }

  /** ----------------------------
   *  DELETE ORDER
   * ----------------------------*/
  async function deleteOrder(id: string) {
    if (!confirm("Are you sure you want to delete this production order?"))
      return;
    setOrders((prev) => prev.filter((o) => o.id !== id));
  }

  function getStatusBadgeClass(status: OrderStatus) {
    switch (status) {
      case "Pending":
        return "bg-red-100 text-red-800";
      case "In Production":
        return "bg-blue-100 text-blue-800";
      case "Completed":
        return "bg-green-100 text-green-800";
      case "Cancelled":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  }

  /** ----------------------------
   *  FILTER + SEARCH
   * ----------------------------*/
  const filteredOrders = orders.filter((order) => {
    const s = searchTerm.trim().toLowerCase();
    const matchesSearch =
      !s ||
      order.order_no?.toLowerCase().includes(s) ||
      order.clients?.client_name?.toLowerCase().includes(s) ||
      order.designs?.design_code?.toLowerCase().includes(s);

    const matchesStatus = !filterStatus || order.status === filterStatus;

    return matchesSearch && matchesStatus;
  });

  if (loading) return <div className="p-8 text-center">Loading...</div>;

  return (
    <div className="h-full flex flex-col bg-[#fefefe]">
      <div className="border-b-2 border-red-700 bg-amber-50 p-4">
        <h1 className="text-3xl font-bold text-red-800">
          Production Issue Register
        </h1>
      </div>

      {/* Search + Filters */}
      <div className="p-4 bg-white border-b border-gray-300 flex gap-4 items-center">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search by order no., client, or design..."
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded"
            value={searchTerm}
            onChange={(e: ChangeEvent<HTMLInputElement>) =>
              setSearchTerm(e.target.value)
            }
          />
        </div>

        <select
          className="px-4 py-2 border border-gray-300 rounded"
          value={filterStatus}
          onChange={(e: ChangeEvent<HTMLSelectElement>) =>
            setFilterStatus(e.target.value)
          }
        >
          <option value="">All Status</option>
          <option value="Pending">Pending</option>
          <option value="In Production">In Production</option>
          <option value="Completed">Completed</option>
          <option value="Cancelled">Cancelled</option>
        </select>

        <button
          onClick={addNewOrder}
          className="flex items-center gap-2 bg-amber-600 text-white px-4 py-2 rounded hover:bg-amber-700"
        >
          <Plus className="h-4 w-4" />
          New Order
        </button>
      </div>

      {/* TABLE */}
      <div className="flex-1 overflow-auto">
        <table className="w-full border-collapse">
          <thead className="sticky top-0 bg-amber-100 border-b-2 border-red-700">
            <tr>
              <th className="border border-gray-300 px-2 py-2 text-red-800 text-sm font-semibold w-32">
                Order No.
              </th>
              <th className="border border-gray-300 px-2 py-2 text-red-800 text-sm font-semibold w-28">
                Date
              </th>
              <th className="border border-gray-300 px-2 py-2 text-red-800 text-sm font-semibold">
                Client/Party
              </th>
              <th className="border border-gray-300 px-2 py-2 text-red-800 text-sm font-semibold w-32">
                Design Code
              </th>
              <th className="border border-gray-300 px-2 py-2 text-red-800 text-sm font-semibold">
                Design Name
              </th>
              <th className="border border-gray-300 px-2 py-2 text-red-800 text-sm font-semibold w-24">
                Lot/Batch
              </th>
              <th className="border border-gray-300 px-2 py-2 text-red-800 text-sm font-semibold w-24">
                Qty Ordered
              </th>
              <th className="border border-gray-300 px-2 py-2 text-red-800 text-sm font-semibold w-24">
                Rate/Pc
              </th>
              <th className="border border-gray-300 px-2 py-2 text-red-800 text-sm font-semibold w-28">
                Total
              </th>
              <th className="border border-gray-300 px-2 py-2 text-red-800 text-sm font-semibold w-28">
                Exp. Delivery
              </th>
              <th className="border border-gray-300 px-2 py-2 text-red-800 text-sm font-semibold w-32">
                Material Issued
              </th>
              <th className="border border-gray-300 px-2 py-2 text-red-800 text-sm font-semibold w-28">
                Status
              </th>
              <th className="border border-gray-300 px-2 py-2 text-red-800 text-sm font-semibold">
                Remarks
              </th>
              <th className="border border-gray-300 px-2 py-2 text-red-800 text-sm font-semibold w-20">
                Actions
              </th>
            </tr>
          </thead>

          <tbody>
            {filteredOrders.map((order) => (
              <tr key={order.id} className="hover:bg-yellow-50">
                {/* ORDER NO */}
                <td className="border border-gray-300 px-2 py-1">
                  <input
                    type="text"
                    className="w-full bg-transparent px-1 py-1 text-sm"
                    value={order.order_no}
                    onBlur={(e: ChangeEvent<HTMLInputElement>) =>
                      updateOrder(order.id, "order_no", e.target.value)
                    }
                  />
                </td>

                {/* DATE */}
                <td className="border border-gray-300 px-2 py-1">
                  <input
                    type="date"
                    className="w-full bg-transparent px-1 py-1 text-sm"
                    value={order.order_date}
                    onBlur={(e: ChangeEvent<HTMLInputElement>) =>
                      updateOrder(order.id, "order_date", e.target.value)
                    }
                  />
                </td>

                {/* CLIENT SELECT */}
                <td className="border border-gray-300 px-2 py-1">
                  <select
                    className="w-full bg-transparent px-1 py-1 text-sm"
                    value={order.client_id || ""}
                    onChange={(e: ChangeEvent<HTMLSelectElement>) =>
                      updateOrder(order.id, "client_id", e.target.value)
                    }
                  >
                    <option value="">Select Client</option>
                    {clients.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.client_name}
                      </option>
                    ))}
                  </select>
                </td>

                {/* DESIGN */}
                <td className="border border-gray-300 px-2 py-1">
                  <select
                    className="w-full bg-transparent px-1 py-1 text-sm"
                    value={order.design_id || ""}
                    onChange={(e: ChangeEvent<HTMLSelectElement>) =>
                      updateOrder(order.id, "design_id", e.target.value)
                    }
                  >
                    <option value="">Select Design</option>
                    {designs.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.design_code}
                      </option>
                    ))}
                  </select>
                </td>

                {/* DESIGN NAME */}
                <td className="border border-gray-300 px-2 py-1 text-sm">
                  {order.designs?.design_name || "-"}
                </td>

                {/* LOT */}
                <td className="border border-gray-300 px-2 py-1">
                  <input
                    type="text"
                    value={order.batch_lot_no || ""}
                    className="w-full bg-transparent px-1 py-1 text-sm"
                    onBlur={(e: ChangeEvent<HTMLInputElement>) =>
                      updateOrder(order.id, "batch_lot_no", e.target.value)
                    }
                  />
                </td>

                {/* QTY */}
                <td className="border border-gray-300 px-2 py-1">
                  <input
                    type="number"
                    className="w-full bg-transparent px-1 py-1 text-sm text-right"
                    value={order.qty_ordered}
                    onBlur={(e: ChangeEvent<HTMLInputElement>) =>
                      updateOrder(
                        order.id,
                        "qty_ordered",
                        Number(e.target.value)
                      )
                    }
                  />
                </td>

                {/* RATE */}
                <td className="border border-gray-300 px-2 py-1">
                  <input
                    type="number"
                    className="w-full bg-transparent px-1 py-1 text-sm text-right"
                    value={order.rate_per_piece}
                    onBlur={(e: ChangeEvent<HTMLInputElement>) =>
                      updateOrder(
                        order.id,
                        "rate_per_piece",
                        Number(e.target.value)
                      )
                    }
                  />
                </td>

                {/* TOTAL (computed) */}
                <td className="border border-gray-300 px-2 py-1 text-right font-medium">
                  {(order.qty_ordered * order.rate_per_piece).toFixed(2)}
                </td>

                {/* EXPECTED DELIVERY */}
                <td className="border border-gray-300 px-2 py-1">
                  <input
                    type="date"
                    className="w-full bg-transparent px-1 py-1 text-sm"
                    value={order.expected_delivery_date || ""}
                    onBlur={(e: ChangeEvent<HTMLInputElement>) =>
                      updateOrder(
                        order.id,
                        "expected_delivery_date",
                        e.target.value
                      )
                    }
                  />
                </td>

                {/* MATERIAL ISSUED */}
                <td className="border border-gray-300 px-2 py-1">
                  <input
                    type="text"
                    className="w-full bg-transparent px-1 py-1 text-sm"
                    value={order.grey_material_issued || ""}
                    onBlur={(e: ChangeEvent<HTMLInputElement>) =>
                      updateOrder(
                        order.id,
                        "grey_material_issued",
                        e.target.value
                      )
                    }
                  />
                </td>

                {/* STATUS */}
                <td className="border border-gray-300 px-2 py-1">
                  <select
                    className={`w-full px-1 py-1 text-xs rounded ${getStatusBadgeClass(
                      order.status
                    )}`}
                    value={order.status}
                    onChange={(e: ChangeEvent<HTMLSelectElement>) =>
                      updateOrder(
                        order.id,
                        "status",
                        e.target.value as OrderStatus
                      )
                    }
                  >
                    <option>Pending</option>
                    <option>In Production</option>
                    <option>Completed</option>
                    <option>Cancelled</option>
                  </select>
                </td>

                {/* REMARKS */}
                <td className="border border-gray-300 px-2 py-1">
                  <input
                    type="text"
                    className="w-full bg-transparent px-1 py-1 text-sm"
                    value={order.remarks || ""}
                    onBlur={(e: ChangeEvent<HTMLInputElement>) =>
                      updateOrder(order.id, "remarks", e.target.value)
                    }
                  />
                </td>

                {/* ACTIONS */}
                <td className="border border-gray-300 px-2 py-1">
                  <div className="flex gap-1 justify-center">
                    <button
                      className="p-1 hover:bg-blue-100 rounded"
                      type="button"
                    >
                      <Eye className="h-4 w-4 text-blue-600" />
                    </button>
                    <button
                      className="p-1 hover:bg-green-100 rounded"
                      type="button"
                    >
                      <QrCode className="h-4 w-4 text-green-600" />
                    </button>
                    <button
                      className="p-1 hover:bg-red-100 rounded"
                      onClick={() => deleteOrder(order.id)}
                      type="button"
                    >
                      <Trash2 className="h-4 w-4 text-red-600" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
